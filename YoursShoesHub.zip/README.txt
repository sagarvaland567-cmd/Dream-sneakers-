Yours Shoes Hub - Demo site
Files included:
- index.html   (main demo page)
- logo.png     (placeholder - replace with your logo)
- gpayqr.jpg   (your Google Pay QR image)
- shoe1-1.jpg  ... shoe6-1.jpg  (product photos; replace with your 3-4 images per model using naming convention)

How to use:
1. Replace logo.png, gpayqr.jpg and shoe images with your actual images.
   Recommended naming: shoe1-1.jpg, shoe1-2.jpg, shoe1-3.jpg for model 1 (gallery options).
2. Zip the folder and deploy to Vercel or Netlify (drag and drop).
3. For live payments (not demo), replace the Buy buttons with links:
   Example UPI link:
   upi://pay?pa=sagarvaland567@okaxis&pn=Yours%20Shoes%20Hub&am=2148&cu=INR
   Use JS to generate amount dynamically for each product when enabling live payments.
